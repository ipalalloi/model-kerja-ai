﻿# Pedoman Arsitektur & Model Kerja Pengembangan Aplikasi Web Universal (v6.0)
*Versi 6.0 — Enterprise, Secure, Responsive, Modern, Multi-Agent Orchestration & Production Clean (Agustus 2026)*

Dokumen ini berisi keputusan arsitektur, standar kualitas, protokol keamanan, responsivitas antarmuka, alur orkestrasi multi-agen, serta prosedur operasional pengodean yang **berlaku untuk semua jenis proyek aplikasi/sistem web** (E-Commerce, Analisis Saham/Stocks, SIM/SPMI, SIMPEL Kelurahan, POS, Portal Informasi, Dashboard Analitik, dll.).

---

## 6 Pilar Utama Kualitas Sistem (Wajib Dipatuhi)

1. **Aman (Secure)**: Pencegahan OWASP Top 10, autentikasi kuat (Session + Argon2id/Bcrypt), otorisasi level objek, proteksi kredensial di `.env`, sanitasi input, escaping output, MIME file validation via `finfo_file()`, rate limiting IP & lockout, serta penanganan error tanpa membocorkan info internal.
2. **Responsif (Responsive)**: Tampilan mobile-first, grid fleksibel (Bootstrap/CSS Grid), touch target minimal 48px, kontainer tabel responsif (`.table-responsive`), dan layout dinamis yang akomodatif untuk seluler, tablet, hingga desktop.
3. **Dinamis (Dynamic)**: Pengalaman pengguna hidup berbasis Fetch API / AJAX tanpa reload penuh halaman, visual state feedback (loading/empty/error), dan pembaruan UI real-time.
4. **Moderen (Modern UI/UX)**: Desain visual kontemporer (sleek dark/light mode, glassmorphism), tipografi modern (Google Fonts: Inter/Roboto/Outfit), micro-animations, dan clean spacing.
5. **Bersih (Clean Code & MVC Architecture)**: Pola Single Responsibility (SRP), pemisahan tegas MVC (Model, View, Controller/Service), kode mudah dirawat (maintainable), dan **bebas dari berkas sampah/sampah artefak AI saat deployment**.
6. **Siap Ekspor ke Mobile Apps (Mobile Ready)**: API terstruktur (`/api/v1/`), autentikasi dual-mode (Session untuk Web, JWT/Bearer Token untuk Mobile), respon JSON terstandar, serta CORS yang terkonfigurasi.

---

## 0. Aturan Otonomi Agen & Modal Persetujuan Pengguna (Kritikal)

### A. Eksekusi Otonom (Tanpa Minta Izin User)
Agen DIBOLEHKAN dan DIWAJIBKAN mengeksekusi secara mandiri tindakan berikut:
1. **Manipulasi Berkas**: Membaca, membuat, mengedit, dan merapikan file proyek (`.php`, `.js`, `.css`, `.html`, `.sql`, `.htaccess`, `.md`, dll.).
2. **Eksekusi Perintah CLI/Terminal**: Perintah pengujian sintaks (`php -l`), analisis struktur, query tes lokal, git status/branch, dan pengemasan ZIP rilis (`build_upload.ps1`).
3. **Perbaikan Bug & Refactoring**: Mengoreksi error, memperbaiki sintaks, menginisialisasi variabel yang belum didefinisikan, perbaikan layout UI/UX, dan penyinkronan error handling.
4. **Pembaruan State Dokumen**: Mengupdate berkas `working.md`, `task.md`, `walkthrough.md`, `MIGRATION_LOG.md`, dan `RELEASE_MANIFEST.md`.

### B. Wajib Meminta Persetujuan Pengguna (Stop & Ask)
Agen HANYA boleh menghentikan proses otonom dan meminta konfirmasi/persetujuan dari Pengguna pada kondisi:
1. **Persetujuan Rancangan Fitur Utama (Implementation Plan)**: Saat menyusun fitur baru berskala besar atau merombak alur utama aplikasi.
2. **Perubahan Skema Database Mayor**: Menghapus tabel utama atau merombak struktur kolom yang berdampak luas.
3. **Perubahan Alur Bisnis / Breaking Changes**: Mengubah logika bisnis sentral yang mempengaruhi alur kerja pengguna yang sudah berjalan.

---

## 1. Integrasi Alur Kerja Multi-Agent Orchestration (AG Orchestra)

Saat menangani fitur kompleks atau perombakan sistem skala menengah-besar, agen wajib mengadopsi alur **AG Orchestra (Multi-Agent Orchestration)**:

1. **Role Orchestrator (Agen Utama)**:
   - Bertindak sebagai Manajer Proyek & Arsitek Sistem.
   - Bertanggung jawab memecah tugas besar menjadi sub-tugas terisolasi.
   - Menyusun `implementation_plan.md` dan meminta persetujuan pengguna (*Stop & Ask*).
   - Memantau kepatuhan sub-agen terhadap aturan ini.
2. **Role Sub-Agent Spesialis**:
   - **Database Agent**: Menangani skema SQL, migration, dan query PDO.
   - **Backend Controller/Service Agent**: Menangani bisnis logic, validasi input, dan API security.
   - **Frontend UI/UX Agent**: Menangani tampilan Bootstrap/CSS, interaktivitas AJAX Fetch, dan responsivitas mobile.
   - **Security & QA Auditor Agent**: Menjalankan pengujian sintaks (`php -l`), memeriksa OWASP, dan memverifikasi kebersihan rilis.
3. **Boundary & Domain Boundaries**: Sub-agen dilarang memodifikasi berkas di luar domain tugasnya tanpa koordinasi Orkestrator.

---

## 2. Arsitektur Terstruktur MVC (Model-View-Controller / Service)

Semua proyek wajib menerapkan arsitektur MVC / Layered Architecture yang rapi:

* **Models (`/models` atau `/src`)**: Menangani interaksi database PDO (Prepared Statements), entity data, dan query mentah.
* **Controllers / API (`/controllers` atau `/api`)**: Menangani penerimaan HTTP request, validasi input (`filter_var`/regex), pemeriksaan sesi/token, otorisasi objek, dan pemanggilan Model/Service. Mengembalikan respon JSON terstandar untuk API.
* **Views (`/views` atau root web pages)**: Menangani antarmuka HTML presentasi. Bebas dari logika query SQL mentah.
* **Services / Helpers (`/includes` atau `/src`)**: Menangani fungsi terpusat (Keamanan, Utilitas File, Kompresi Gambar, PDF, Notifikasi, Integrasi API Eksternal).

---

## 3. Keamanan Sistem & Hardening Lingkungan

### A. Manajemen Kredensial & Lingkungan
* **Keamanan Kredensial**: Informasi sensitif (database credentials, API keys, secret tokens) **dilarang di-hardcode**. Semua nilai sensitif disimpan di file `.env` di root proyek.
* **File Sensitif di `.gitignore`**: `.env`, `.cursorrules`, `uploads/`, `*.sql`, `*.csv`, `dist_upload*.zip`, `logs/`, `working.md`, `_ai_context/` wajib terdaftar di `.gitignore`.
* **Pemisahan Config per Environment**:
  ```
  config/
    database.php            <- Loader generik (TIDAK diubah oleh agen)
    database.local.php      <- Kredensial development (ada di .gitignore)
    database.production.php <- Kredensial live (TIDAK disimpan di repo)
  ```

### B. Session Hardening & Security Guard
* **Session Hardening**: Wajib dikonfigurasi saat pembentukan sesi:
  ```php
  ini_set('session.cookie_httponly', '1');
  ini_set('session.cookie_samesite', 'Strict');
  ini_set('session.cookie_secure', (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? '1' : '0');
  session_start();
  ```
* **Session Regeneration**: Wajib mengeksekusi `session_regenerate_id(true)` setelah login berhasil untuk mencegah Session Fixation attacks.
* **Real-time Access & Session Sync**: Sesi pengguna wajib disinkronkan secara real-time dari database pada setiap request kritikal. Jika status user dinonaktifkan (`status = 0`) atau dihapus (`deleted_at IS NOT NULL`), sesi wajib dibatalkan (*invalidated*) seketika.
* **CSRF Token**: Wajib dibuat via `bin2hex(random_bytes(32))` dan diverifikasi via `hash_equals()` pada setiap mutasi data berbasis Web Session.

### C. Rate Limiting, File Upload & Security Headers
* **IP Rate Limiting & Lockout**: Endpoint login/autentikasi dan verifikasi PIN/OTP wajib memiliki lockout otomatis (misal 5x gagal = lockout 15 mnt). Sediakan modul unblock IP aman bagi Superadmin.
* **Keamanan Upload File & Kompresi**:
  1. Validasi whitelist ekstensi file.
  2. **Wajib validasi MIME type sebenarnya** menggunakan `finfo_file()`.
  3. Rename file dengan nama hash unik (`bin2hex(random_bytes(16))`).
  4. Otomatiskan kompresi dan penyesuaian ukuran gambar (*image resizing & compression*) untuk efisiensi server.
* **Proteksi Akses HTTP Webroot**: Folder sensitif (`config/`, `src/`, `models/`, `migrations/`, `install/`) wajib dilindungi via `.htaccess` (`Require all denied`). Folder `uploads/` wajib memiliki `.htaccess` yang mematikan eksekusi script server-side (`php_flag engine off`).

---

## 4. Analisis Kepatuhan Prosedur & Penegakan Aturan (Anti-Bypass Protocol)

Untuk mengatasi masalah di mana **tahapan dan aturan sering terlewati atau tidak dijalankan**, agen AI wajib mematuhi **Checklist Anti-Bypass**:

1. **Wajib Baca `working.md` di AWAL Sesi**: Sebelum menyentuh kode, agen wajib membaca `working.md` untuk memahami konteks terakhir dan tidak mengulang pekerjaan yang sudah selesai.
2. **Wajib Verifikasi Variabel Sebelum Selesai**: Sebelum menyatakan tugas selesai, agen wajib memeriksa bahwa semua variabel (seperti `$resultSet`, `$approvalRows`, dll.) telah diinisialisasi untuk mencegah *undefined variable error*.
3. **Wajib Tes Sintaks (`php -l`)**: Semua file PHP yang diubah wajib dites sintaksnya via CLI sebelum dilaporkan ke pengguna.
4. **Wajib Update `working.md` di AKHIR Sesi**: Agen tidak boleh mengakhiri sesi tanpa meng-update status `working.md`.

---

## 5. Protokol Kebersihan ZIP Rilis Live & Pembersihan Sampah

Saat membuat paket ZIP rilis untuk diunggah ke server live (`build_upload.ps1`), **WAJIB MEMBERSIHKAN dan MENGECEK** berkas berikut agar tidak ikut terunggah:

### A. Berkas/Folder Internal AI & Development yang Wajib Dibuang:
- `working.md`
- `task.md`
- `implementation_plan.md`
- `walkthrough.md`
- `_ai_context/`
- `*.ai_draft`
- `.cursorrules`
- `.vscode/` & `.idea/`
- `node_modules/`

### B. Berkas Backup & Sampah Tambahan yang Wajib Dibuang:
- **Semua berkas archive lama**: `dist_upload*.zip`, `*.rar`, `*.tar.gz`, `*.7z` (misal: `dist_upload_20260720_1406.zip`, `_project_template_2.rar`, `simpel_mobile_app.zip`).
- **Semua berkas backup manual**: `*.old`, `*.bak`, `index.php.old`, `*.tmp`, `*.swp`.
- **Semua file dump SQL & data sampel internal**: `*.sql` (misal: `db_spmi_pemetaan.sql`), `*.csv` sampel.
- **Berkas OS Junk**: `Thumbs.db`, `.DS_Store`, `desktop.ini`.
- **Berkas Kredensial**: `.env`, `.env.local` (gunakan `.env.example` di repo; `.env` live dibuat di server).

### C. Pembaruan Script Automasi `build_upload.ps1`:
Script `build_upload.ps1` wajib dikonfigurasi dengan regex exclusion yang ketat untuk memastikan paket ZIP 100% bersih.

---

## 6. Antarmuka Modern, Responsif & Mobile Ready

* **Modern UI/UX**: Palet warna kontras tinggi yang nyaman (a11y), tipografi modern (Inter/Roboto/Outfit), layout dinamis.
* **Mobile-First & Touch-Friendly**: Target elemen interaktif minimal **48×48px**, kontainer `.table-responsive` untuk tabel data.
* **AJAX / Fetch API**: Pembaruan UI tanpa reload halaman dengan visual state feedback (*Loading*, *Empty*, dan *Error State*).
* **Mobile Ready API**: Endpoint `/api/v1/` berversi, respon JSON terstandar (`{"success": bool, "message": "...", "data": {}}`), autentikasi Dual-Mode (Session/Token), serta header CORS.

---

## 7. Kontinuitas Kerja AI (working.md) & Release Manifest

* **`working.md`**: Memori eksternal AI di root proyek (ada di `.gitignore`) yang dicatat dan dibaca setiap sesi.
* **`RELEASE_MANIFEST.md`**: Mencatat setiap versi rilis live beserta SHA256 checksum berkas ZIP dan langkah rollback.
