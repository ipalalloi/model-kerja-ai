﻿# Working State — [Nama Proyek]
*Terakhir diperbarui: YYYY-MM-DD HH:MM oleh [nama AI/sesi]*

## Status Proyek Saat Ini
[Satu paragraf singkat: fase apa, fitur apa yang sedang dikerjakan, kendala apa]

## Tugas Terakhir Selesai
- [x] (kosong — belum ada)

## Tugas Sedang Berjalan — LANJUTKAN DARI SINI
- [/] Setup awal proyek

## Antrian Tugas Berikutnya
- [ ] ...

## Keputusan Arsitektural Penting
- [YYYY-MM-DD] ...

## File Kritis untuk Dibaca Sebelum Melanjutkan
- `config/database.php`
- `migrations/MIGRATION_LOG.md`

## Peringatan & Catatan Khusus
- (kosong)

## Pengujian Manual Perlu Dilakukan
- [ ] Uji login semua role
