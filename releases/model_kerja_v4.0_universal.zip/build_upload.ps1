﻿# build_upload.ps1
# Jalankan SEBELUM upload ke server live untuk membersihkan artefak AI

$date = Get-Date -Format "yyyyMMdd_HHmm"
$output = "dist_upload_$date.zip"
$excludePatterns = "working\.md|task\.md|implementation_plan\.md|walkthrough\.md|_ai_context|Thumbs\.db|\.DS_Store|\.vscode|\.idea|node_modules|vendor|dist_upload.*\.zip|\.old$|\.sql$|\.env$|\.cursorrules|\\logs\\|\\migrations\\"

Write-Host "Membuat paket upload: $output" -ForegroundColor Cyan
Write-Host "Mengecualikan artefak AI dan file sensitif..." -ForegroundColor Yellow

Get-ChildItem -Path "." -Recurse -File |
    Where-Object { $_.FullName -notmatch $excludePatterns } |
    ForEach-Object { $_.FullName } |
    Compress-Archive -DestinationPath $output -Update -ErrorAction SilentlyContinue

if (Test-Path $output) {
    $hash = (Get-FileHash $output).Hash
    Write-Host "Selesai: $output" -ForegroundColor Green
    Write-Host "SHA256: $hash" -ForegroundColor Green
    Write-Host ""
    Write-Host "PERIKSA isi zip sebelum upload!" -ForegroundColor Red
    Write-Host "Catat SHA256 di RELEASE_MANIFEST.md" -ForegroundColor Yellow
} else {
    Write-Host "ERROR: Paket gagal dibuat." -ForegroundColor Red
}
