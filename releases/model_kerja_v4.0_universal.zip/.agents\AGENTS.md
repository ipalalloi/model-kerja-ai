﻿# Pedoman Arsitektur & Model Kerja Pengembangan Aplikasi Web General
*Versi 4.0 — Universal, Secure, Responsive, Modern, Clean & Mobile-Ready (Juli 2026)*

Dokumen ini berisi pedoman arsitektur dasar, standar kualitas, keamanan, responsivitas antarmuka, serta prosedur operasional pengodean yang **berlaku untuk semua jenis aplikasi/sistem web** (E-Commerce, SIM/SPMI, POS, Portal Informasi, Dashboard Analitik, dll.).

---

## 6 Pilar Utama Aplikasi / Sistem (WajibDipatuhi)

1. **Aman (Secure)**: Mencegah OWASP Top 10, autentikasi kuat, otorisasi di level objek, proteksi kredensial, sanitasi input, escaping output, dan penanganan error tanpa membocorkan sistem internal.
2. **Responsif (Responsive)**: Tampilan mobile-first, grid fleksibel, ramah sentuh (touch target min 48px), tabel responsif, dan layout dinamis yang menyesuaikan berbagai ukuran layar (mobile, tablet, desktop).
3. **Dinamis (Dynamic)**: Pengalaman pengguna hidup dengan Fetch API / AJAX tanpa reload penuh halaman, state feedback visual (loading/empty/error), dan pembaruan UI real-time yang lancar.
4. **Moderen (Modern)**: Desain visual elegan (glassmorphism/sleek dark-light mode), modern typography (Inter/Roboto/Outfit), micro-animations, clean spacing, dan arsitektur UI/UX kontemporer.
5. **Bersih (Clean Code)**: Pola Single Responsibility (SRP), pemisahan logika bisnis (service) dan logika presentasi (view), standar penulisan rapi, dan mudah dirawat (maintainable).
6. **Siap Ekspor ke Mobile Apps (Mobile Ready)**: Arsitektur API terpisah (`/api/v1/`), autentikasi dual-mode (Session untuk Web, JWT/Bearer Token untuk Mobile), format respon JSON terstandar, dan dukungan CORS terkonfigurasi.

---

## 0. Aturan Otonomi Agen & Modal Persetujuan Pengguna (Kritikal)

### A. Eksekusi Otonom (Tanpa Minta Izin User)
Agen DIBOLEHKAN dan DIWAJIBKAN mengeksekusi secara mandiri tindakan berikut:
1. **Manipulasi Berkas**: Membaca, membuat, mengedit, dan merapikan file proyek (`.php`, `.js`, `.css`, `.html`, `.sql`, `.htaccess`, `.md`, dll.).
2. **Eksekusi Perintah CLI/Terminal**: Perintah pengujian sintaks (`php -l`), analisis struktur, query tes lokal, git status/branch, dan pengemasan ZIP rilis (`build_upload.ps1`).
3. **Perbaikan Bug & Refactoring**: Mengoreksi error, memperbaiki sintaks, menginisialisasi variabel yang belum didefinisikan, perbaikan layout UI/UX, dan penyinkronan error handling.
4. **Pembaruan State Dokumen**: Mengupdate berkas `working.md`, `task.md`, `walkthrough.md`, `MIGRATION_LOG.md`, dan `RELEASE_MANIFEST.md`.

### B. Wajib Meminta Persetujuan Pengguna (Stop & Ask)
Agen HANYA boleh menghentikan proses otonom dan meminta konfirmasi/persetujuan dari Pengguna pada kondisi:
1. **Persetujuan Rancangan Fitur Utama (Implementation Plan)**: Saat menyusun fitur baru berskala besar atau merombak alur utama aplikasi.
2. **Perubahan Skema Database Mayor**: Menghapus tabel utama atau merombak struktur kolom yang berdampak luas.
3. **Perubahan Alur Bisnis / Breaking Changes**: Mengubah logika bisnis sentral yang mempengaruhi alur kerja pengguna yang sudah berjalan.

---

## 1. Keamanan System & Lingkungan (Secure System)

* **Keamanan Kredensial**: Informasi sensitif (database credentials, API keys, secret tokens) **dilarang di-hardcode**. Semua nilai sensitif disimpan di file `.env` di root proyek.
* **File Sensitif di `.gitignore`**: `.env`, `.cursorrules`, `uploads/`, `*.sql`, `*.csv`, `dist_upload*.zip`, `logs/`, `working.md`, `_ai_context/` wajib terdaftar di `.gitignore`.
* **Pemisahan Config per Environment**:
  ```
  config/
    database.php            <- Loader generik (TIDAK diubah oleh agen)
    database.local.php      <- Kredensial development (ada di .gitignore)
    database.production.php <- Kredensial live (TIDAK disimpan di repo)
  ```
* **Proteksi Akses HTTP Webroot**: Folder sensitif (`config/`, `src/`, `migrations/`, `install/`) wajib dilindungi via `.htaccess` (`Require all denied`). Folder `uploads/` wajib memiliki `.htaccess` yang mematikan eksekusi script server-side (`php_flag engine off`).
* **Sanitasi & Validasi Input**: Semua input pengguna wajib divalidasi tipe dan formatnya di layer API controller sebelum diproses ke logika bisnis.
* **Pencegahan XSS & CSP**: Escape output HTML menggunakan `htmlspecialchars($data, ENT_QUOTES, 'UTF-8')`. Hindari inline event handlers (`onclick="..."`) — daftarkan via `addEventListener()` di JS eksternal.
* **Object-Level Authorization & Scope Check**: Setiap operasi mutasi data (create, update, delete, approve, lock) wajib memverifikasi bahwa resource tersebut memang milik/berada dalam otorisasi pengguna yang sedang login.
* **Keamanan File Upload**:
  1. Validasi whitelist ekstensi file yang diizinkan.
  2. **Wajib validasi MIME type sebenarnya** menggunakan `finfo_file()`.
  3. Rename file dengan nama hash unik (`uniqid() . '_' . bin2hex(random_bytes(8))`).
* **Rate Limiting**: Pasang rate limit pada endpoint login, endpoint verifikasi PIN/OTP, dan endpoint publik/AI untuk mencegah brute-force dan abuse.
* **Pencegahan Kebocoran Exception**: Exception database/system (`PDOException`) dilarang bocor ke antarmuka pengguna. Selalu tangkap error -> log ke berkas internal -> tampilkan pesan ramah pengguna.

---

## 2. Kualitas Kode, Performa & Modularitas (Clean & Lightweight)

* **Tag Penutup PHP**: Hilangkan tag `?>` di akhir file PHP murni untuk mencegah masalah whitespace/header.
* **Strict Types**: Tempatkan `declare(strict_types=1);` pada baris pertama file backend.
* **PDO Prepared Statements**: Semua query dinamis wajib memakai Prepared Statements (`PDO::FETCH_ASSOC`, `PDO::ATTR_EMULATE_PREPARES => false`).
* **Standarisasi Path**: Gunakan `__DIR__` sebagai basis path pemuatan file (`require_once __DIR__ . '/../config/database.php'`).
* **Tipe Data Angka & Presisi**: Untuk data nilai numerik/keuangan/persentase yang membutuhkan presisi, gunakan tipe data database `DECIMAL`, bukan `FLOAT`/`DOUBLE`.
* **Desain Skema Database**: Gunakan `TINYINT(1)` untuk status boolean. Terapkan index pada Foreign Key dan kolom filter utama. Gunakan Soft Delete (`deleted_at`) pada data penting.
* **Pola Single Responsibility (SRP)**:
  * Layer `api/`: Routing, validasi input, memanggil service, mengembalikan JSON.
  * Layer `src/` (Service): Logika bisnis, kueri database, kalkulasi.
  * Layer `views/`: Tampilan HTML presentasi.
* **Anti N+1 Query**: Gunakan JOIN atau batch querying untuk memuat data terikat, hindari kueri di dalam loop iterasi.
* **Migration Ledger (WAJIB)**: Semua perubahan skema database dicatat secara urut di berkas `migrations/MIGRATION_LOG.md` beserta berkas SQL migrasinya.

---

## 3. Antarmuka Modern, Dinamis & Responsif (UX/UI Excellence)

* **Desain Visual Moderen**: Gunakan palet warna yang harmonis, tipografi modern (Google Fonts: Inter / Roboto / Outfit), kartu berdesain bersih, dan kontras warna yang nyaman (a11y).
* **Mobile-First & Responsif**:
  * Layout fleksibel yang menyesuaikan otomatis dari ponsel pintar hingga layar lebar.
  * Target elemen interaktif (tombol, input, link) minimal **48×48px** untuk kenyamanan sentuhan jari.
  * Tabel data yang lebar wajib dibungkus kontainer responsif (`.table-responsive`).
* **Interaksi Dinamis (AJAX/Fetch)**:
  * Pembaruan data tanpa perlu memuat ulang seluruh halaman.
  * **Visual State Feedback**: Tampilkan *Loading State* (spinner/opacity), *Empty State* ("Data belum tersedia" saat kosong), dan *Error State* (notifikasi Toast ramah pengguna jika terjadi kendala).

---

## 4. Kesiapan Integrasi Mobile Apps (Mobile Apps Ready)

* **Arsitektur API Terpisah**: Sediakan struktur endpoint berversi (misal: `/api/v1/`) yang memisahkan logika antarmuka web dan API mobile.
* **Autentikasi Dual-Mode**:
  * **Web Session**: Menggunakan Session Cookie + CSRF Token.
  * **Mobile API**: Menggunakan Bearer Token (JWT atau Opaque API Token).
* **Format Respon JSON Standar**:
  ```json
  {
    "success": true,
    "message": "Pesan status operasional",
    "data": { }
  }
  ```
* **HTTP Status Code Presisi**: `200` (OK), `201` (Created), `400` (Bad Request), `401` (Unauthorized), `403` (Forbidden), `404` (Not Found), `422` (Unprocessable Entity/Validation Error), `429` (Too Many Requests), `500` (Server Error).
* **CORS Configured**: Konfigurasikan header CORS dengan daftar origin yang diizinkan untuk kebutuhan integrasi aplikasi mobile.

---

## 5. Kontinuitas Kerja AI & Manajemen Sesi (working.md)

File `working.md` berfungsi sebagai **"memori eksternal AI"** di root proyek (terdaftar di `.gitignore`). File ini menjamin pengembang/agen AI dapat berganti akun, berganti model, atau melanjutkan sesi tanpa kehilangan konteks.

**Format Wajib `working.md`**:
```markdown
# Working State — [Nama Sistem/Aplikasi]
*Terakhir diperbarui: YYYY-MM-DD HH:MM oleh [Nama Agen/Sesi]*

## Status Proyek Saat Ini
[Ringkasan singkat: fase pengembangan, fitur yang sedang dikerjakan, kendala]

## Tugas Terakhir Selesai
- [x] Deskripsi tugas selesai

## Tugas Sedang Berjalan — LANJUTKAN DARI SINI
- [/] Deskripsi tugas belum selesai
  - Sub-langkah sudah dilakukan: ...
  - Sub-langkah belum dilakukan: ...

## Antrian Tugas Berikutnya
- [ ] Tugas A

## Keputusan Arsitektural Penting
- [YYYY-MM-DD] Keputusan X diambil karena alasan Y

## File Kritis untuk Dibaca Sebelum Melanjutkan
- `config/database.php`, `src/NamaService.php`, `migrations/MIGRATION_LOG.md`
```

**Aturan Wajib `working.md`**:
1. Diperbarui di akhir setiap sesi kerja.
2. Wajib dibaca di awal setiap sesi baru sebelum menyentuh kode.
3. Saat berganti AI/akun, agen baru membaca `working.md` dan langsung melanjutkan tugas "IN PROGRESS".

---

## 6. Protokol Deployment & Rilis Paket

* **Kebersihan Paket Upload (Artefak AI)**: Sebelum mengemas ZIP untuk server live, berkas internal development/AI wajib dikecualikan: `working.md`, `task.md`, `implementation_plan.md`, `walkthrough.md`, `_ai_context/`, `*.sql`, `.env`, `.cursorrules`, `logs/`, `migrations/`.
* **Script Automation**: Gunakan script helper `build_upload.ps1` untuk mengemas ZIP rilis secara otomatis dan bersih.
* **Release Manifest**: Catat setiap versi rilis pada `RELEASE_MANIFEST.md` beserta SHA256 checksum paket dan rencana rollback.
