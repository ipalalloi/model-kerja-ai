﻿# Pedoman Arsitektur & Model Kerja Pengembangan Aplikasi PHP
*Versi 3.1 — Pembaruan Konsolidasi & Aturan Otonomi Agen (Juli 2026)*

Dokumen ini berisi keputusan arsitektur, standar penulisan kode, konfigurasi database, prosedur deployment, protokol kontinuitas kerja AI, serta aturan otonomi agen. Semua agen AI dan pengembang yang bekerja pada repositori ini wajib mematuhi aturan berikut **tanpa pengecualian**. Ketidakpatuhan terhadap aturan ini adalah cacat proses, bukan pilihan.

---

## 0. Aturan Otonomi Agen & Modal Persetujuan Pengguna (Kritikal)

### A. Eksekusi Otonom (Tanpa Minta Izin User)
Agen DIBOLEHKAN dan DIWAJIBKAN untuk secara langsung mengeksekusi tindakan berikut **tanpa bertanya/meminta izin per-perintah**:
1. **Manipulasi File**: Membaca, membuat, mengedit, dan menghapus file proyek (`.php`, `.js`, `.css`, `.html`, `.sql`, `.htaccess`, `.md`, dll.).
2. **Perintah Terminal/PowerShell**: Mengeksekusi perintah CLI lingkungan proyek (misal: `git`, `php -l`, pemindaian berkas, pembuatan ZIP rilis `build_upload.ps1`, query database lokal).
3. **Penyelesaian Bug & Refactoring**: Mengoreksi bug, memperbaiki sintaks, menginisialisasi variabel (seperti `$approvalRows`), menyinkronkan penanganan kesalahan, dan perbaikan tata letak UI/UX.
4. **Pembaruan Memori State**: Mengupdate secara otomatis file `working.md`, `task.md`, `walkthrough.md`, `MIGRATION_LOG.md`, dan `RELEASE_MANIFEST.md`.

### B. Wajib Meminta Persetujuan Pengguna (Stop & Ask / Confirmation Required)
Agen HANYA boleh menghentikan proses otonom dan meminta konfirmasi/persetujuan eksplisit dari Pengguna pada kondisi:
1. **Persetujuan Rancangan Arsitektur / Implementation Plan**: Ketika merancang usulan fitur baru yang berskala besar atau perubahan alur utama.
2. **Perubahan Skema Database Mayor**: Menghapus tabel utama atau merombak struktur kolom yang berdampak luas.
3. **Perubahan Alur Bisnis / Breaking Changes**: Mengubah logika bisnis sentral yang mempengaruhi alur kerja pengguna yang sudah berjalan.

---

## 1. Manajemen Kredensial & Lingkungan (Environment)

* **Keamanan Kredensial**: Informasi sensitif (database credentials, API keys, secret tokens) **tidak boleh di-hardcode** di dalam kode. Semua nilai sensitif wajib disimpan di file `.env` di root proyek.
* **File `.env` dan `.cursorrules` harus terdaftar di `.gitignore`**. File `.cursorrules` bisa mengandung API key editor AI dan harus selalu diabaikan oleh Git.
* **`.gitignore` wajib mencakup minimal**: `.env`, `.cursorrules`, `uploads/`, `*.old`, `*.sql`, `*.csv`, `dist_upload*.zip`, `.vscode/`, `.idea/`, `Thumbs.db`, `.DS_Store`, `vendor/`, `node_modules/`, `logs/`, `working.md`, `_ai_context/`.
* **APP_ENV Flag**: Definisikan variabel `APP_ENV` di `.env` dengan nilai `'development'` atau `'production'`.
* **Kredensial Default Wajib Dihapus**: Akun demo/seed (`admin123`, dll.) **tidak boleh pernah ter-deploy ke server live**.

### Manajemen Config per Environment
* **LARANGAN KERAS**: Agen AI **tidak boleh memodifikasi, menimpa, atau overwrite** file `config/database.php` tanpa instruksi eksplisit pengguna.
* **Pola Pemisahan Config yang Wajib**:
  ```
  config/
    database.php            <- Loader saja, TIDAK mengandung kredensial
    database.local.php      <- Kredensial development (ada di .gitignore)
    database.production.php <- TIDAK di repo; diupload manual ke server
  ```
* **`config/database.php`** hanya berisi logika pemilihan:
  ```php
  <?php
  declare(strict_types=1);
  date_default_timezone_set('Asia/Makassar');
  mb_internal_encoding('UTF-8');
  $env = getenv('APP_ENV') ?: 'local';
  $configFile = __DIR__ . "/database.{$env}.php";
  if (!file_exists($configFile)) {
      $configFile = __DIR__ . '/database.local.php';
  }
  require_once $configFile;
  ```
* Setiap kali agen menyentuh file di `config/`, wajib mendeklarasikan: *"Saya tidak mengubah `database.local.php` atau `database.production.php`."*

---

## 2. Standar Penulisan Kode PHP (PSR-12 & PHP Modern)

* **Tag Penutup PHP**: Semua file PHP murni **wajib menghilangkan `?>`** di akhir file.
* **Strict Types**: `declare(strict_types=1);` wajib di baris pertama **semua file PHP**.
* **Keamanan Query**: Wajib **PDO Prepared Statements** untuk semua query dinamis.
* **Mode Fetch PDO**: `PDO::FETCH_ASSOC` + `PDO::ATTR_EMULATE_PREPARES => false`.
* **Standarisasi Path**: Gunakan `__DIR__` — bukan path relatif `'../'`.
  ```php
  require_once __DIR__ . '/../config/database.php'; // BENAR
  ```
* **JSON Encoding**: Flag `JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE` selalu.
* **Type Hints**: Wajib pada semua file kelas/service baru. Bertahap pada file lama.
* **Testing Pragmatis Tanpa CI/CD**:
  * **Smoke Test Manual**: Dokumentasikan URL/endpoint yang perlu diuji di `walkthrough.md`.
  * **Cek Functional Defect**: Pastikan variabel dalam loop/array (seperti `$approvalRows`, `$resultSet`) diinisialisasi sebelum digunakan.
  * **Anti-Regression Checklist**: (1) Halaman utama render tanpa error, (2) Login/logout berjalan, (3) Endpoint dimodifikasi menghasilkan JSON valid.

---

## 3. Desain Skema Database & Migration Ledger

* **Boolean**: `TINYINT(1)`. FK: `ON DELETE CASCADE` atau `ON DELETE SET NULL` sesuai semantik.
* **Nilai Akademik**: `DECIMAL(5,2)`, bukan `FLOAT`/`DOUBLE`.
* **Index**: Wajib pada semua FK dan kolom filter (`status`, `created_at`, `user_id`).
* **Soft Delete**: `deleted_at TIMESTAMP NULL DEFAULT NULL` untuk data kritikal.
* **PDO ATTR_INIT_COMMAND**: `SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci, time_zone = '+08:00', wait_timeout = 30`.
* **Singleton**: Pola `!isset($pdo)` — satu koneksi per request.
* **Migration Ledger (WAJIB)**:
  * File `migrations/MIGRATION_LOG.md` adalah satu-satunya sumber kebenaran skema.
  * Setiap perubahan skema: buat file SQL di `migrations/` → catat di `MIGRATION_LOG.md` → laporkan di `walkthrough.md`.

---

## 4. Pola Antarmuka Pengguna & AJAX Live-Update

* **Layout**: Matriks agregat di level Master/Mata Kuliah, detail CPMK di Bootstrap Collapse.
* **Checkbox**: Agregat read-only; detail CPMK interaktif via Fetch API.
* **UX**: Loading state (opacity 0.5), Empty state ("Data belum tersedia"), Error state + rollback (Toast merah).
* **Aksesibilitas (a11y)**: Tombol icon-only wajib `aria-label`. Form error wajib `aria-describedby` + `aria-invalid`.

---

## 5. Alur Kerja Agen & Kontinuitas AI (working.md)

### Protokol Kontinuitas Ganti Sesi / Akun AI — `working.md`
File `working.md` adalah **"memori eksternal" AI** (simpan di root proyek, wajib di `.gitignore`).

**Format Wajib**:
```markdown
# Working State — [Nama Proyek]
*Terakhir diperbarui: YYYY-MM-DD HH:MM oleh [nama AI/sesi]*

## Status Proyek Saat Ini
[Ringkasan singkat: fase, fitur yang dikerjakan, kendala]

## Tugas Terakhir Selesai
- [x] Deskripsi

## Tugas Sedang Berjalan — LANJUTKAN DARI SINI
- [/] Deskripsi
  - Sub-langkah sudah dilakukan: ...
  - Sub-langkah belum dilakukan: ...

## Antrian Tugas Berikutnya
- [ ] Tugas A

## Keputusan Arsitektural Penting
- [YYYY-MM-DD] Keputusan X karena Y

## File Kritis untuk Dibaca Sebelum Melanjutkan
- `config/database.php`, `src/NamaService.php`, `migrations/MIGRATION_LOG.md`

## Peringatan & Catatan Khusus
- [PERINGATAN] Jangan ubah kolom X karena Y
```

**Aturan Wajib**:
1. Diperbarui setelah setiap sesi kerja.
2. Wajib dibaca di awal setiap sesi baru — sebelum melihat kode.
3. Saat ganti AI/akun: Agen baru membaca `working.md` → melanjutkan tugas "IN PROGRESS".

---

## 6. Standar Keamanan & Mobile Ready

* **Input Validation**: `filter_var()` atau regex di layer API sebelum service layer.
* **XSS & CSP**: `htmlspecialchars($data, ENT_QUOTES, 'UTF-8')`. Gunakan `addEventListener()`, bukan inline `onclick`.
* **CSRF Token**: Wajib untuk form web (session). Tidak untuk JWT/Bearer token.
* **Object-Level & Scope Check**: Operasi kritikal (regenerate/revoke signature, approve, lock) wajib memverifikasi bahwa resource berada dalam scope/milik pengguna yang login.
* **MIME Validation**: Validasi file upload **wajib menggunakan `finfo_file()`**, bukan sekadar ekstensi.
* **Rate Limiting**: Login (max 5 gagal/10mnt), AI endpoint (max 10/jam), PIN eksternal 6-digit (rate limit ketat setara login).
* **Error Reporting**: Exception database (PDOException) dilarang bocor ke output pengguna. Catch → log server → kirim pesan generik.
* **Mobile-Ready**: Web UI (Session + CSRF), Mobile `/api/v1/` (Bearer Token JWT). Response standar `{"success": bool, "message": "...", "data": {}}`.

---

## 7. Proteksi Webroot & Deployment Checklist

### Mitigasi Webroot / Shared Hosting
Sertakan `.htaccess` di folder sensitif (`config/`, `src/`, `migrations/`, `install/`) dengan aturan:
```apacheconf
Options -Indexes
<FilesMatch ".*">
    <IfModule mod_authz_core.c>
        Require all denied
    </IfModule>
    <IfModule !mod_authz_core.c>
        Order deny,allow
        Deny from all
    </IfModule>
</FilesMatch>
```

### Kebersihan Paket Upload (Artefak AI)
File yang **WAJIB dikecualikan dari ZIP live**: `working.md`, `task.md`, `implementation_plan.md`, `walkthrough.md`, `_ai_context/`, `*.sql`, `.env`, `.cursorrules`, `logs/`, `migrations/`.
* Gunakan script `build_upload.ps1` untuk pengemasan otomatis.
* Catat rilis di `RELEASE_MANIFEST.md` beserta SHA256 checksum-nya.
