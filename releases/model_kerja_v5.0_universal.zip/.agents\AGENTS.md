﻿# Pedoman Arsitektur & Model Kerja Pengembangan Aplikasi Web Universal
*Versi 5.0 — Universal, Secure, Responsive, Modern, Clean & Mobile-Ready (Agustus 2026)*

Dokumen ini berisi keputusan arsitektur, standar kualitas, protokol keamanan, responsivitas antarmuka, serta alur operasional pengodean yang **berlaku untuk semua jenis proyek aplikasi/sistem web** (E-Commerce, SIM/SPMI, SIMPEL Kelurahan, POS, Portal Informasi, Dashboard Analitik, dll.).

---

## 6 Pilar Utama Kualitas Sistem (Wajib Dipatuhi)

1. **Aman (Secure)**: Pencegahan OWASP Top 10, autentikasi kuat, otorisasi di level objek, proteksi kredensial, sanitasi input, escaping output, MIME file validation via `finfo_file()`, rate limiting IP & lockout, serta penanganan error tanpa membocorkan info internal.
2. **Responsif (Responsive)**: Tampilan mobile-first, grid fleksibel, touch target minimal 48px, kontainer tabel responsif, dan layout dinamis yang akomodatif untuk seluler, tablet, hingga desktop.
3. **Dinamis (Dynamic)**: Pengalaman pengguna hidup berbasis Fetch API / AJAX tanpa reload penuh halaman, visual state feedback (loading/empty/error), dan pembaruan UI real-time.
4. **Moderen (Modern UI/UX)**: Desain visual kontemporer (sleek dark/light mode, glassmorphism), tipografi modern (Inter/Roboto/Outfit), micro-animations, dan clean spacing.
5. **Bersih (Clean Code)**: Pola Single Responsibility (SRP), pemisahan tegas logika bisnis (service/model) dan logika presentasi (view), kode mudah dirawat (maintainable).
6. **Siap Ekspor ke Mobile Apps (Mobile Ready)**: API terstruktur (`/api/v1/`), autentikasi dual-mode (Session untuk Web, JWT/Bearer Token untuk Mobile), respon JSON terstandar, serta CORS yang terkonfigurasi.

---

## 0. Aturan Otonomi Agen & Modal Persetujuan Pengguna (Kritikal)

### A. Eksekusi Otonom (Tanpa Minta Izin User)
Agen DIBOLEHKAN dan DIWAJIBKAN mengeksekusi secara mandiri tindakan berikut:
1. **Manipulasi Berkas**: Membaca, membuat, mengedit, dan merapikan file proyek (`.php`, `.js`, `.css`, `.html`, `.sql`, `.htaccess`, `.md`, dll.).
2. **Eksekusi Perintah CLI/Terminal**: Perintah pengujian sintaks (`php -l`), analisis struktur, query tes lokal, git status/branch, dan pengemasan ZIP rilis (`build_upload.ps1`).
3. **Perbaikan Bug & Refactoring**: Mengoreksi error, memperbaiki sintaks, menginisialisasi variabel yang belum didefinisikan, perbaikan layout UI/UX, dan penyinkronan error handling.
4. **Pembaruan State Dokumen**: Mengupdate berkas `working.md`, `task.md`, `walkthrough.md`, `MIGRATION_LOG.md`, dan `RELEASE_MANIFEST.md`.

### B. Wajib Meminta Persetujuan Pengguna (Stop & Ask)
Agen HANYA boleh menghentikan proses otonom dan meminta konfirmasi/persetujuan dari Pengguna pada kondisi:
1. **Persetujuan Rancangan Fitur Utama (Implementation Plan)**: Saat menyusun fitur baru berskala besar atau merombak alur utama aplikasi.
2. **Perubahan Skema Database Mayor**: Menghapus tabel utama atau merombak struktur kolom yang berdampak luas.
3. **Perubahan Alur Bisnis / Breaking Changes**: Mengubah logika bisnis sentral yang mempengaruhi alur kerja pengguna yang sudah berjalan.

---

## 1. Keamanan Sistem & Hardening Lingkungan

### A. Manajemen Kredensial & Lingkungan
* **Keamanan Kredensial**: Informasi sensitif (database credentials, API keys, secret tokens) **dilarang di-hardcode**. Semua nilai sensitif disimpan di file `.env` di root proyek.
* **File Sensitif di `.gitignore`**: `.env`, `.cursorrules`, `uploads/`, `*.sql`, `*.csv`, `dist_upload*.zip`, `logs/`, `working.md`, `_ai_context/` wajib terdaftar di `.gitignore`.
* **Pemisahan Config per Environment**:
  ```
  config/
    database.php            <- Loader generik (TIDAK diubah oleh agen)
    database.local.php      <- Kredensial development (ada di .gitignore)
    database.production.php <- Kredensial live (TIDAK disimpan di repo)
  ```

### B. Session Hardening & Security Guard (Praktek Terbaik Real Proyek)
* **Session Hardening**: Wajib dikonfigurasi saat pembentukan sesi:
  ```php
  ini_set('session.cookie_httponly', '1');
  ini_set('session.cookie_samesite', 'Strict');
  ini_set('session.cookie_secure', (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? '1' : '0');
  session_start();
  ```
* **Session Regeneration**: Wajib mengeksekusi `session_regenerate_id(true)` setelah login berhasil untuk mencegah Session Fixation attacks.
* **Real-time Access & Session Sync**: Sesi pengguna wajib disinkronkan secara real-time dari database pada setiap request kritikal. Jika status user dinonaktifkan (`status = 0`) atau dihapus (`deleted_at IS NOT NULL`), sesi wajib dibatalkan (*invalidated*) seketika.
* **CSRF Token**: Wajib dibuat via `bin2hex(random_bytes(32))` dan diverifikasi via `hash_equals()` pada setiap mutasi data berbasis Web Session.

### C. Rate Limiting & Proteksi Upload File
* **IP Rate Limiting & Lockout**:
  * Endpoint login/autentikasi: Batasi percobaan gagal (misal max 5 kali gagal per IP/akun) dengan lockout otomatis 15 menit.
  * Catat dan sediakan fitur unblock IP aman untuk administrator.
* **Keamanan Upload File & Kompresi Otomatis**:
  1. Validasi whitelist ekstensi file.
  2. **Wajib validasi MIME type sebenarnya** menggunakan `finfo_file()`.
  3. Rename file dengan nama hash unik (`bin2hex(random_bytes(16))`).
  4. Otomatiskan kompresi dan penyesuaian ukuran gambar (*image resizing & compression*) untuk menjaga efisiensi ruang simpan server dan kecepatan muat.
* **Proteksi Akses HTTP Webroot**: Folder sensitif (`config/`, `src/`, `migrations/`, `install/`) wajib dilindungi via `.htaccess` (`Require all denied`). Folder `uploads/` wajib memiliki `.htaccess` yang mematikan eksekusi script server-side (`php_flag engine off`).
* **Pencegahan Kebocoran Exception**: Exception database/system (`PDOException`) dilarang bocor ke antarmuka pengguna. Catch -> log ke berkas internal -> tampilkan pesan ramah pengguna.

---

## 2. Kualitas Kode, Performa & Modularitas

* **Tag Penutup PHP**: Hilangkan tag `?>` di akhir file PHP murni untuk mencegah masalah whitespace/header.
* **Strict Types**: Tempatkan `declare(strict_types=1);` pada baris pertama file backend.
* **PDO Prepared Statements**: Semua query dinamis wajib memakai Prepared Statements (`PDO::FETCH_ASSOC`, `PDO::ATTR_EMULATE_PREPARES => false`).
* **Standarisasi Path**: Gunakan `__DIR__` sebagai basis path pemuatan file (`require_once __DIR__ . '/../config/database.php'`).
* **Tipe Data Angka & Presisi**: Untuk data nilai numerik/keuangan/persentase yang membutuhkan presisi, gunakan tipe data database `DECIMAL`, bukan `FLOAT`/`DOUBLE`.
* **Desain Skema Database**: Gunakan `TINYINT(1)` untuk status boolean. Terapkan index pada Foreign Key dan kolom filter utama. Gunakan Soft Delete (`deleted_at`) pada data penting.
* **Pola Single Responsibility (SRP)**:
  * Layer `api/`: Routing, validasi input, memanggil service/model, mengembalikan JSON.
  * Layer `src/` atau `models/`: Logika bisnis, kueri database, kalkulasi.
  * Layer `views/`: Tampilan HTML presentasi.
* **Anti N+1 Query**: Gunakan JOIN atau batch querying untuk memuat data terikat, hindari kueri di dalam loop iterasi.
* **Migration Ledger (WAJIB)**: Semua perubahan skema database dicatat secara urut di berkas `migrations/MIGRATION_LOG.md` beserta berkas SQL migrasinya.

---

## 3. Antarmuka Modern, Dinamis & Responsif (UX/UI Excellence)

* **Desain Visual Moderen**: Gunakan palet warna yang harmonis, tipografi modern (Google Fonts: Inter / Roboto / Outfit), kartu berdesain bersih, dan kontras warna yang nyaman (a11y).
* **Mobile-First & Responsif**:
  * Layout fleksibel yang menyesuaikan otomatis dari ponsel pintar hingga layar lebar.
  * Target elemen interaktif (tombol, input, link) minimal **48×48px** untuk kenyamanan sentuhan jari.
  * Tabel data yang lebar wajib dibungkus kontainer responsif (`.table-responsive`).
* **Interaksi Dinamis (AJAX/Fetch)**:
  * Pembaruan data tanpa perlu memuat ulang seluruh halaman.
  * **Visual State Feedback**: Tampilkan *Loading State* (spinner/opacity), *Empty State* ("Data belum tersedia" saat kosong), dan *Error State* (notifikasi Toast ramah pengguna jika terjadi kendala).

---

## 4. Kesiapan Integrasi Mobile Apps (Mobile Apps Ready)

* **Arsitektur API Terpisah**: Sediakan struktur endpoint berversi (misal: `/api/v1/`) yang memisahkan logika antarmuka web dan API mobile.
* **Autentikasi Dual-Mode**:
  * **Web Session**: Menggunakan Session Cookie + CSRF Token.
  * **Mobile API**: Menggunakan Bearer Token (JWT atau Opaque API Token).
* **Format Respon JSON Standar**:
  ```json
  {
    "success": true,
    "message": "Pesan status operasional",
    "data": { }
  }
  ```
* **HTTP Status Code Presisi**: `200` (OK), `201` (Created), `400` (Bad Request), `401` (Unauthorized), `403` (Forbidden), `404` (Not Found), `422` (Unprocessable Entity/Validation Error), `429` (Too Many Requests), `500` (Server Error).
* **CORS Configured**: Konfigurasikan header CORS dengan daftar origin yang diizinkan untuk kebutuhan integrasi aplikasi mobile.

---

## 5. Kontinuitas Kerja AI & Manajemen Sesi (working.md)

File `working.md` berfungsi sebagai **"memori eksternal AI"** di root proyek (terdaftar di `.gitignore`). File ini menjamin pengembang/agen AI dapat berganti akun, berganti model, atau melanjutkan sesi tanpa kehilangan konteks.

**Format Wajib `working.md`**:
```markdown
# Working State — [Nama Sistem/Aplikasi]
*Terakhir diperbarui: YYYY-MM-DD HH:MM oleh [Nama Agen/Sesi]*

## Status Proyek Saat Ini
[Ringkasan singkat: fase pengembangan, fitur yang sedang dikerjakan, kendala]

## Tugas Terakhir Selesai
- [x] Deskripsi tugas selesai

## Tugas Sedang Berjalan — LANJUTKAN DARI SINI
- [/] Deskripsi tugas belum selesai
  - Sub-langkah sudah dilakukan: ...
  - Sub-langkah belum dilakukan: ...

## Antrian Tugas Berikutnya
- [ ] Tugas A

## Keputusan Arsitektural Penting
- [YYYY-MM-DD] Keputusan X diambil karena alasan Y

## File Kritis untuk Dibaca Sebelum Melanjutkan
- `config/database.php`, `src/NamaService.php`, `migrations/MIGRATION_LOG.md`
```

**Aturan Wajib `working.md`**:
1. Diperbarui di akhir setiap sesi kerja.
2. Wajib dibaca di awal setiap sesi baru sebelum menyentuh kode.
3. Saat berganti AI/akun, agen baru membaca `working.md` dan langsung melanjutkan tugas "IN PROGRESS".

---

## 6. Protokol Deployment & Rilis Paket

* **Kebersihan Paket Upload (Artefak AI)**: Sebelum mengemas ZIP untuk server live, berkas internal development/AI wajib dikecualikan: `working.md`, `task.md`, `implementation_plan.md`, `walkthrough.md`, `_ai_context/`, `*.sql`, `.env`, `.cursorrules`, `logs/`, `migrations/`.
* **Script Automation**: Gunakan script helper `build_upload.ps1` untuk mengemas ZIP rilis secara otomatis dan bersih.
* **Release Manifest**: Catat setiap versi rilis pada `RELEASE_MANIFEST.md` beserta SHA256 checksum paket dan rencana rollback.
